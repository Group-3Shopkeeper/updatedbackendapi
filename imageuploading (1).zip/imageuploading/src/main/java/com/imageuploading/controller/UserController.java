package com.imageuploading.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Bucket;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.firebase.cloud.StorageClient;

import com.imageuploading.bean.User;
import com.imageuploading.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
 
	@Autowired
	UserService userService;
	@PostMapping("/")
	  public ResponseEntity<?> createUser(@RequestParam("file") MultipartFile file, @RequestParam("name") String name, @RequestParam("mobile") String mobile) throws Exception {
	    if(file.isEmpty())
		  throw new Exception();
	    
	    User user = new User();
        user.setMobile(mobile);
	    user.setName(name);
	    
	    User u = userService.createUser(file, user);
	    return new ResponseEntity<User>(u,HttpStatus.OK);
	}
}
