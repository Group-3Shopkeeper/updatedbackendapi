package com.imageuploading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageuploadingApplicationTests {

	@Test
	void contextLoads() {
	}

}
